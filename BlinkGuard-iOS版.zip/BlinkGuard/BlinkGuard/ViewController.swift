import UIKit
import WebKit

class ViewController: UIViewController, WKNavigationDelegate, WKUIDelegate {
    
    var webView: WKWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // 配置 WebView
        let config = WKWebViewConfiguration()
        config.preferences.javaScriptEnabled = true
        config.preferences.javaScriptCanOpenWindowsAutomatically = true
        config.allowsInlineMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = []
        
        webView = WKWebView(frame: view.bounds, configuration: config)
        webView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        webView.navigationDelegate = self
        webView.uiDelegate = self
        webView.allowsBackForwardNavigationGestures = true
        webView.scrollView.bounces = false
        view.addSubview(webView)
        
        // 加载本地打包的 PWA 资源
        if let indexURL = Bundle.main.url(forResource: "index", withExtension: "html", subdirectory: "web") {
            let directoryURL = indexURL.deletingLastPathComponent()
            webView.loadFileURL(indexURL, allowingReadAccessTo: directoryURL)
        }
    }
    
    // 处理摄像头/麦克风权限请求
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        // 隐藏 APK 下载按钮（原生应用不需要）
        webView.evaluateJavaScript("""
            const btn = document.querySelector('a[download]');
            if (btn) btn.style.display = 'none';
            if (navigator.serviceWorker) {
                navigator.serviceWorker.getRegistrations().then(rs => rs.forEach(r => r.unregister()));
            }
        """, completionHandler: nil)
    }
    
    // 支持 window.open 等
    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        if navigationAction.targetFrame == nil {
            webView.load(navigationAction.request)
        }
        return nil
    }
}
