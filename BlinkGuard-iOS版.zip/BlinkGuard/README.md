# 眨眨护眼 - iOS 原生版（本地应用）

> iOS 原生应用，所有界面资源打包在应用内部（`web/` 目录），无需联网即可打开。
> AI 对话、姿态检测等功能需联网加载模型。

## 技术方案

采用 **WKWebView 加载本地资源** 方案：
- 原生 iOS App 外壳（图标、启动器、全屏、权限管理）
- PWA 所有资源打包在 `BlinkGuard/web/` 目录
- WKWebView 通过 `loadFileURL` 加载本地 `index.html`
- 复用 PWA 全部功能

## 工程结构

```
BlinkGuard/
├── BlinkGuard/
│   ├── AppDelegate.swift          # 应用入口
│   ├── ViewController.swift       # 主页面（WKWebView 加载本地资源）
│   ├── Info.plist                 # 权限声明（相机/麦克风）
│   ├── Assets.xcassets/           # 应用图标、颜色
│   └── web/                       # ★ PWA 本地资源
│       ├── index.html
│       ├── style.css
│       ├── app.js
│       ├── manifest.json
│       └── icon-*.png
└── BlinkGuard.xcodeproj/
```

## 构建步骤

### 1. 环境准备
- 安装 **Xcode 15+**
- 安装 iOS 17+ SDK
- 配置 Apple Developer 账号

### 2. 打开工程
1. 双击 `BlinkGuard.xcodeproj` 打开
2. 选择 Team（签名证书）
3. 修改 Bundle Identifier（如 `com.blinkguard.app`）

### 3. 运行
- **模拟器**：选择 iPhone 模拟器 → Cmd+R
- **真机**：连接 iPhone → Cmd+R

### 4. 打包 IPA
- `Product` → `Archive` → `Distribute App`

## 注意事项

1. **完全本地运行**：界面资源打包在 app 内，无需联网打开
2. **AI 功能需联网**：大模型、MediaPipe、Whisper 模型从 CDN 加载
3. **权限**：首次使用摄像头/麦克风会弹窗申请
4. **ATS 已关闭**：`NSAllowsArbitraryLoads = YES`，允许加载 HTTP 资源
