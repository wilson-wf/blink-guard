# 眨眨护眼 - 鸿蒙原生版（本地应用）

> 真正的鸿蒙原生应用，所有界面资源打包在应用内部，**不依赖网络加载页面**。
> AI 对话、在线语音识别等功能仍需联网，但应用主体完全本地运行。

## 技术方案

采用 **ArkWeb 本地资源加载** 方案：
- 原生鸿蒙 App 外壳（图标、启动器、全屏、权限管理）
- PWA 所有资源（HTML/CSS/JS/图片）打包在 `entry/src/main/resources/rawfile/` 目录
- WebView 通过 `$rawfile('index.html')` 加载本地资源，**无需联网即可打开应用**
- 复用 PWA 全部功能（姿态检测、语音识别、AI 对话、小怪兽装扮）

## 与 PWA 版的区别

| 特性 | PWA 网页版 | 鸿蒙原生版 |
|------|-----------|-----------|
| 资源位置 | GitHub Pages 远程 | 打包在应用内（rawfile） |
| 打开应用 | 需要联网 | 完全本地，无需联网 |
| 安装方式 | 浏览器"添加到桌面" | 安装 HAP/APP |
| 权限管理 | 浏览器弹窗 | 系统级权限申请 |
| APK 下载按钮 | 有 | 自动隐藏（已安装） |
| Service Worker | 启用（缓存） | 禁用（资源已在本地） |

## 工程结构

```
BlinkGuard/
├── AppScope/                      # 应用级配置
│   ├── app.json5                  # 应用包名、版本、图标、名称
│   └── resources/base/
│       ├── element/string.json    # 应用名称"眨眨护眼"
│       └── media/app_icon.png     # 应用图标
├── entry/                         # 主模块
│   ├── src/main/
│   │   ├── ets/
│   │   │   ├── entryability/EntryAbility.ets   # 应用入口
│   │   │   └── pages/Index.ets                 # 主页面（加载本地 rawfile）
│   │   ├── module.json5           # 模块配置 + 权限声明
│   │   └── resources/
│   │       ├── base/               # 系统资源（颜色、字符串、图标）
│   │       └── rawfile/            # ★ PWA 本地资源（打包进应用）
│   │           ├── index.html      # 主页
│   │           ├── style.css       # 样式
│   │           ├── app.js          # 全部逻辑
│   │           ├── manifest.json   # PWA 清单
│   │           ├── icon-192.png    # 图标
│   │           └── icon-512.png    # 图标
│   ├── build-profile.json5
│   └── hvigorfile.ts
├── build-profile.json5            # 项目级构建配置
├── hvigorfile.ts
├── oh-package.json5
├── hvigorw / hvigorw.bat          # 构建脚本
└── README.md
```

## 关键配置

### 权限（module.json5）
| 权限 | 用途 |
|------|------|
| `ohos.permission.INTERNET` | 调用 AI 服务、加载 MediaPipe/Whisper 模型 |
| `ohos.permission.CAMERA` | 坐姿检测（页面内 getUserMedia） |
| `ohos.permission.MICROPHONE` | 语音交互 |
| `ohos.permission.GET_NETWORK_INFO` | 网络状态检测 |

### SDK 版本
- `compileSdkVersion`: 12
- `compatibleSdkVersion`: 9（兼容 HarmonyOS 3.1+）
- `targetSdkVersion`: 12

### 本地资源加载（Index.ets）
```typescript
Web({ src: $rawfile('index.html'), controller: this.webviewController })
  .fileAccess(true)
  .fileFromUrlAccess(true)
  .mixedMode(webview.MixedMode.All)  // 允许本地页面加载网络资源（AI/模型CDN）
```

## 构建运行步骤

### 1. 环境准备
- 安装 **DevEco Studio**（建议 5.0+）
- 安装 HarmonyOS SDK（API 9 及以上）
- 配置 ohpm 镜像（国内建议使用华为云镜像）

### 2. 打开工程
1. 启动 DevEco Studio
2. `File` → `Open` → 选择 `BlinkGuard` 目录
3. 等待 ohpm 自动同步依赖

### 3. 签名配置
1. `File` → `Project Structure` → `Project` → `Signing Configs`
2. 勾选 `Automatically generate signature`（自动生成调试签名）
3. 或手动配置 `.p12` 证书

### 4. 运行
- **模拟器**：`Tools` → `Device Manager` → 创建 Phone 模拟器 → 运行
- **真机**：连接鸿蒙手机（开启开发者模式+USB调试）→ 运行

### 5. 打包 HAP/APP
- `Build` → `Build Hap(s)/APP(s)` → `Build Hap(s)` 生成 `.hap`
- 或 `Build APP(s)` 生成 `.app`（上架应用市场用）

## 注意事项

1. **完全本地运行**：应用界面资源打包在 rawfile，无需联网即可打开
2. **AI 功能需联网**：大模型对话、MediaPipe 姿态检测、Whisper 语音模型需从 CDN 加载
3. **相机/麦克风权限**：首次启动会弹窗申请，授权后功能才能使用
4. **网页权限自动授权**：`onPermissionRequest` 回调中已自动 grant 网页请求的资源权限
5. **返回键**：优先在网页内后退，无法后退时退出应用
6. **APK 下载按钮已隐藏**：原生应用无需下载 APK，页面加载后自动隐藏该按钮

## 更新 PWA 内容

如需更新应用内的页面内容：
1. 修改 `entry/src/main/resources/rawfile/` 下的文件
2. 重新构建 HAP/APP 即可
3. 注意：rawfile 中的资源引用不要带 `?v=xx` 版本参数
